
module.exports = {
    images: {
        domains: ['localhost', 'res.cloudinary.com', 'carspace.uz', 'sleeksoul.com']
    }
};

// /** @type {import('next').NextConfig} */
// const nextConfig = {
//     images: {
//         domains: ['localhost', 'res.cloudinary.com']
//     }
// }
//
// module.exports = nextConfig
