export const getRelatedProducts = async (categoryIds: string[]) => {

}